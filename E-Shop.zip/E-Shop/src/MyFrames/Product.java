package MyFrames;

public class Product {
    private String id;
    private String pname;
    private int available;
    
    public Product(String id, String pname,int available)
    {
        this.id=id;
        this.pname=pname;
        this.available=available; 
    }
            
    public String getid()
    {
        return id;
    }
    public String getpname()
    {
        return pname;
    }
    public int getavailable()
    {
        return available;
    }
  }


